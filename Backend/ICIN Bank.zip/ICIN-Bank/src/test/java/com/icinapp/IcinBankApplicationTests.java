package com.icinapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IcinBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
